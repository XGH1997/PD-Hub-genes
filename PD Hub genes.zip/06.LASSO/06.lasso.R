#LASSO 回归也叫套索回归，是通过生成一个惩罚函数是回归模型中的变量系数进行压缩，达到防止过度拟合，解决严重共线性的问题，
#LASSO 回归最先由英国人Robert Tibshirani提出，目前在预测模型中应用非常广泛。对于变量过多而且变量数较少的模型拟合，首先要考虑使用LASSO 惩罚函数。
#install.packages("glmnet")
#在基因数据的分析中，经常会用到lasso(套索）这种方法来进行变量的筛选，其实就是在目标优化函数后边加一个L1正则化项，其中参数lamda为超参数，需要我们去确定。
#接下来以线性回归为例介绍其在R语言中的实现，当然在logistic回归、cox回归也是可用lasso的。

set.seed(12345)
library(glmnet)     #引用包,glmnet包也是构建逻辑回归模型用的
inputFile="diffGeneExp.txt"       #输入文件
setwd("D:/user/桌面/PD作品/2022年9月版本/LASSO")      #设置工作目录

#读取输入文件
rt=read.table(inputFile, header=T, sep="\t", check.names=F, row.names=1)
rt=t(rt)
#目前，glmnet包只能接受矩阵形式的数据，数据框的数据会报错，所以我们先要把数据转换成矩阵形式，这一步很重要。
#构建模型。Y是结果，X是数据的变量。随着lambdas增加，自由度和残差减少，最小lambda为xxxx
x=as.matrix(rt)
y=gsub("(.*)\\_(.*)", "\\2", row.names(rt))
fit=glmnet(x, y, family = "binomial", alpha=1)
cvfit=cv.glmnet(x, y, family="binomial", alpha=1,type.measure='deviance',nfolds = 10)  #10折交叉验证
#在这里对应于mse最小的lamda即为我们最终采用的lamda,lambda.min就是所求，大小约为0.097
#得出最佳lamda值
sprintf('Best lambda for LASSO: %f.', cvfit$lambda.min)
#验证lambda.min对应的是不是最小的mse
cvfit$lambda[which(cvfit$cvm==min(cvfit$cvm))]

#绘制Lasso回归的图形
pdf(file="lasso.pdf", width=6, height=5.5)
plot(fit)
dev.off()
#绘制交叉验证的图形,即对号线
pdf(file="cvfit.pdf",width=6,height=5.5)
plot(cvfit)
dev.off()
cvfit$lambda.min
cvfit$lambda.1se
#绘制log Lambda曲线
pdf(file ="Lasso1.pdf",width=8,height=5.5)
fit1 =glmnet(x, y, family = "binomial")
plot(fit1,xvar = "lambda", label = TRUE)
dev.off()
#返回参数的系数，可以看到只剩下N个变量
coef(cvfit,s = "lambda.min")

#输出筛选的特征基因
coef=coef(fit, s=cvfit$lambda.min)
index=which(coef != 0)
lassoGene=row.names(coef)[index]
lassoGene=lassoGene[-1]
write.table(lassoGene, file="LASSO.gene.txt", sep="\t", quote=F, row.names=F, col.names=F)


