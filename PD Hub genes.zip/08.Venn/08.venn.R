

#install.packages("venn")


library(venn)                   #???ð?
outFile="interGenes.txt"        #?????ļ?????
setwd("D:/user/桌面/NWGCNA/Venntwo")    #???ù???Ŀ¼
geneList=list()

#??ȡlasso?ع??Ľ????ļ?
rt=read.table("LASSO.gene.txt", header=F, sep="\t", check.names=F)
geneNames=as.vector(rt[,1])       #??ȡ????????
uniqGene=unique(geneNames)        #????ȡunique
geneList[["Lasso"]]=uniqGene

#??ȡSVM?Ľ????ļ?
rt=read.table("SVM-RFE.gene.txt", header=F, sep="\t", check.names=F)
geneNames=as.vector(rt[,1])       #??ȡ????????
uniqGene=unique(geneNames)        #????ȡunique
geneList[["mSVM-RFE"]]=uniqGene

#????vennͼ
mycol=c("blue2","red2")
pdf(file="venn.pdf", width=5, height=5)
venn(geneList,col=mycol[1:length(geneList)],zcolor=mycol[1:length(geneList)],box=F,ilabels=F)
dev.off()

#???潻??????
intersectGenes=Reduce(intersect,geneList)
write.table(file=outFile, intersectGenes, sep="\t", quote=F, col.names=F, row.names=F)

