

#expFile="australian.dat"      #表达数据文件
geneFile="normalize1.txt"      #交集基因的列表文件
setwd("D:/user/桌面/PD作品/2022年9月版本/ROC")    #设置工作目录
australian=read.table(geneFile, header=T, sep="\t", check.names=F)
#australian=read.table("australian.dat")
#View(australian)
#head(australian)
#读取行数
N = length(australian$status)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             
#ind=1的是0.7概率出现的行，ind=2是0.3概率出现的行
ind=sample(2,N,replace=TRUE,prob=c(0.7,0.3)) #2代表2种类型
#生成训练集(这里训练集和测试集随机设置为原数据集的70%，30%)
aus_train <- australian[ind==1,]
#生成测试集
aus_test <- australian[ind==2,]
#生成logis模型，用glm函数



#用训练集数据生成logis模型，用glm函数
#family：每一种响应分布（指数分布族）允许各种关联函数将均值和线性预测器关联起来。常用的family：binomal(link='logit')--响应变量服从二项分布，连接函数为logit，即logistic回归
pre <- glm(status~DLK1+IARS+DLD,family=binomial(link = "logit"),data = aus_train)
summary(pre)

#验证集的真实值
real <- aus_test$status
#predict函数可以获得模型的预测值。这里预测所需的模型对象为pre，预测对象newdata为测试集,预测所需类型type选择response,对响应变量的区间进行调整
predict. <- predict.glm(pre,type='response',newdata=aus_test)
#按照预测值为1的概率，>0.5的返回1，其余返回0
predict =ifelse(predict.>0.5,1,0)
#数据中加入预测值一列
aus_test$predict = predict
#导出结果为csv格式
#write.csv(aus_test,"aus_test.csv")


##模型检验
res <- data.frame(real,predict)
#训练数据的行数，也就是样本数量
n = nrow(aus_train)      
#计算Cox-Snell拟合优度
R2 <- 1-exp((pre$deviance-pre$null.deviance)/n)    
cat("Cox-Snell R2=",R2,"\n")
#计算Nagelkerke拟合优度，我们在最后输出这个拟合优度值
R2<-R2/(1-exp((-pre$null.deviance)/n))  
cat("Nagelkerke R2=",R2,"\n")
##模型的其他指标
#residuals(pre)     #残差
#coefficients(pre)  #系数，线性模型的截距项和每个自变量的斜率，由此得出线性方程表达式。或者写为coef(pre)
#anova(pre)         #方差


#准确率和精度

true_value=aus_test[,1]   #status
predict_value=aus_test[,13103]   #预测的那一列
#计算模型精确度
error = predict_value-true_value
accuracy = (nrow(aus_test)-sum(abs(error)))/nrow(aus_test) #精确度--判断正确的数量占总数的比例


#判断正确的数量占总数的比例 
#真实值预测值全为1 / 预测值全为1 --- 提取出的正确信息条数/提取出的信息条数 

#计算Precision，Recall和F-measure
#一般来说，Precision就是检索出来的条目（比如：文档、网页等）有多少是准确的，Recall就是所有准确的条目有多少被检索出来了
#和混淆矩阵结合，Precision计算的是所有被检索到的item（TP+FP）中,"应该被检索到的item（TP）”占的比例；Recall计算的是所有检索到的item（TP）占所有"应该被检索到的item（TP+FN）"的比例。
precision=sum(true_value & predict_value)/sum(predict_value)  #真实值预测值全为1 / 预测值全为1 --- 提取出的正确信息条数/提取出的信息条数
recall=sum(predict_value & true_value)/sum(true_value)  #真实值预测值全为1 / 真实值全为1 --- 提取出的正确信息条数 /样本中的信息条数

#P和R指标有时候会出现的矛盾的情况，这样就需要综合考虑他们，最常见的方法就是F-Measure（又称为F-Score）
F_measure=2*precision*recall/(precision+recall)    #F-Measure是Precision和Recall加权调和平均，是一个综合评价指标


#输出以上各结果
print(accuracy)
print(precision)
print(recall)
print(F_measure)
#混淆矩阵，显示结果依次为TP、FN、FP、TN
table(true_value,predict_value)         




#ROC曲线
#install.packages("pROC")
library(pROC)
modelroc <- roc(true_value,predict.)
pdf(file="ROC.model.pdf", width=5, height=4.75)
plot(modelroc, print.auc=TRUE, auc.polygon=TRUE,legacy.axes=TRUE, grid=c(0.1, 0.2),
     grid.col=c("green", "red"), max.auc.polygon=TRUE,
     auc.polygon.col="skyblue", print.thres=TRUE) 
#text(0.39, 0.43, paste0("95% CI: ",sprintf("%.03f",ciVec[1]),"-",sprintf("%.03f",ciVec[3])), col="red")#画出ROC曲线，标出坐标，并标出AUC的值
dev.off()

