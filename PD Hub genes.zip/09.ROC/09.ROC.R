
#install.packages("glmnet")
#install.packages("pROC")


#引用包
library(glmnet)
library(pROC)

expFile="normalize.txt"      #表达数据文件
geneFile="interGenes.txt"      #交集基因的列表文件
setwd("D:/user/桌面/PD作品/2022年9月版本/testROC/GSE20292")    #设置工作目录

#读取输入文件
rt=read.table(expFile, header=T, sep="\t", check.names=F, row.names=1)

#获取样品的分组信息
y=gsub("(.*)\\_(.*)", "\\2", colnames(rt))
y=ifelse(y=="con", 0, 1)

#读取基因的列表文件
geneRT=read.table(geneFile, header=F, sep="\t", check.names=F)

#对交集基因进行循环，绘制ROC曲线
bioCol=rainbow(nrow(geneRT), s=0.9, v=0.9)    #定义图形的颜色
aucText=c()
k=0
for(x in as.vector(geneRT[,1])){
  k=k+1
  #绘制ROC曲线
  roc1=roc(y, as.numeric(rt[x,]))     #得到ROC曲线的参数
  if(k==1){
    pdf(file="ROC.genes.pdf", width=5, height=4.75)
    plot(roc1, print.auc=F, col=bioCol[k], legacy.axes=T, main="")
    aucText=c(aucText, paste0(x,", AUC=",sprintf("%.3f",roc1$auc[1])))
  }else{
    plot(roc1, print.auc=F, col=bioCol[k], legacy.axes=T, main="", add=TRUE)
    aucText=c(aucText, paste0(x,", AUC=",sprintf("%.3f",roc1$auc[1])))
  }
}
#绘制图例，得到ROC曲线下的面积
legend("bottomright", aucText, lwd=2, bty="n", col=bioCol[1:(ncol(rt)-1)])
dev.off()
